#!/usr/bin/env python3
import argparse
import ast
import json
import math
import os
import sys
from datetime import date, datetime


CONFIG = {
    "lineName": "P3D (D1c)_EQP MAIN",
    "selectLine": "PFB3",
    "device": "D1c",
    "eadsRoot": "/appdata/hadoop/code/eads",
    "pmCodePath": "/appdata/abnormal_trend/pic/pm_code_info.parquet",
}

LOADER_VERSION = "file-loader-v30"
IS_MAIN_LINE = True
FOLDER_PATH = f"{CONFIG['eadsRoot']}/{CONFIG['selectLine']}/{CONFIG['device']}"
FCC_FOLDER_PATH = f"{CONFIG['eadsRoot']}/{CONFIG['selectLine']}/{CONFIG['device']}_fcc"
FCC_STEP_PATH = f"{FCC_FOLDER_PATH}/fcc_step"
LINE_MAPPING_PATH = os.environ.get("LINE_MAPPING_PATH") or f"{CONFIG['eadsRoot']}/line_mapping.txt"
COMPACT_TIME_FORMATS = (
    "%Y%m%d%H%M%S",
    "%Y%m%d%H%M",
    "%y%m%d%H%M%S",
    "%y%m%d%H%M",
    "%Y%m%d",
)
DATA_SOURCES = [
    {
        "key": "spec",
        "label": "Measure SPEC",
        "path": f"{CONFIG['eadsRoot']}/{CONFIG['selectLine']}/{CONFIG['device']}_measure_spec.parquet",
    },
    {
        "key": "fail",
        "label": "중심치 이상 목록",
        "path": f"{FOLDER_PATH}/{'main_fail_list.parquet' if IS_MAIN_LINE else 'fail_list.parquet'}",
    },
    {
        "key": "std",
        "label": "산포 이상 목록",
        "path": f"{FOLDER_PATH}/{'main_fail_list_std.parquet' if IS_MAIN_LINE else 'fail_list_std.parquet'}",
    },
    {
        "key": "met",
        "label": "MET 매핑",
        "path": f"{CONFIG['eadsRoot']}/{CONFIG['selectLine']}/met.txt",
    },
    {
        "key": "pm",
        "label": "PM 이력",
        "path": CONFIG["pmCodePath"],
    },
]

FCC_DATA_SOURCES = [
    {
        "key": "fcc_step_met",
        "label": "FCC 스탭 MET 매핑",
        "path": f"{FCC_STEP_PATH}/met_fcc.txt",
    },
    {
        "key": "fcc_fail",
        "label": "FCC 중심치 이상 목록",
        "path": f"{FCC_STEP_PATH}/fail_list.parquet",
    },
    {
        "key": "fcc_extra_met",
        "label": "FCC 추가 MET 매핑",
        "path": f"{FCC_FOLDER_PATH}/met_fcc.txt",
    },
    {
        "key": "fcc_extra_fail",
        "label": "FCC 추가 중심치 이상 목록",
        "path": f"{FCC_FOLDER_PATH}/fail_list.parquet",
    },
    {
        "key": "fcc_extra_std",
        "label": "FCC 추가 산포 이상 목록",
        "path": f"{FCC_FOLDER_PATH}/fail_list_std.parquet",
    },
]

CHAMBER_DATA_SOURCES = [
    {
        "key": "line_mapping",
        "label": "개별 챔버 이상감지 라인 매핑파일",
        "path": LINE_MAPPING_PATH,
    }
]


def json_default(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    try:
        import numpy as np

        if isinstance(value, np.integer):
            return int(value)
        if isinstance(value, np.floating):
            return float(value)
        if isinstance(value, np.ndarray):
            return value.tolist()
    except Exception:
        pass
    return str(value)


def epoch_datetime(value):
    try:
        return datetime.fromtimestamp(value / 1000 if abs(value) > 10_000_000_000 else value)
    except Exception:
        return None


def parse_time_value(value):
    if value is None:
        return None
    if hasattr(value, "to_pydatetime"):
        value = value.to_pydatetime()
    if isinstance(value, datetime):
        return value
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day)

    text = ""
    if isinstance(value, (int, float)) and value == value:
        number = int(value)
        text = str(number)
        if text.isdigit():
            for fmt in COMPACT_TIME_FORMATS:
                if len(text) == len(datetime.now().strftime(fmt)):
                    try:
                        return datetime.strptime(text, fmt)
                    except ValueError:
                        pass
        return epoch_datetime(value)

    text = str(value).strip()
    if not text:
        return None

    digits = text.split(".", 1)[0]
    if digits.isdigit():
        for fmt in COMPACT_TIME_FORMATS:
            if len(digits) == len(datetime.now().strftime(fmt)):
                try:
                    return datetime.strptime(digits, fmt)
                except ValueError:
                    pass
        number = int(digits)
        if len(digits) in (10, 13) or number > 10_000_000_000:
            return epoch_datetime(number)

    normalized = text.replace("/", "-").replace("Z", "+00:00")
    if "." in normalized:
        head, tail = normalized.split(".", 1)
        fraction = ""
        suffix = ""
        for char in tail:
            if char.isdigit() and not suffix:
                fraction += char
            else:
                suffix += char
        if len(fraction) > 6:
            normalized = f"{head}.{fraction[:6]}{suffix}"

    try:
        return datetime.fromisoformat(normalized)
    except ValueError:
        return None


def time_text(value):
    parsed = parse_time_value(value)
    if parsed is not None:
        return parsed.isoformat(sep=" ")
    return "" if value is None else str(value)


def time_ms(value):
    parsed = parse_time_value(value)
    if parsed is None:
        return None
    try:
        return int(parsed.timestamp() * 1000)
    except Exception:
        return None


def write_json(payload):
    print(json.dumps(payload, ensure_ascii=False, default=json_default))


def load_polars():
    try:
        import polars as pl

        return pl
    except ImportError as exc:
        raise RuntimeError("parquet 파일을 읽으려면 Python 패키지 polars가 필요합니다.") from exc


def source_status(sources=DATA_SOURCES):
    statuses = []
    for source in sources:
        path = source["path"]
        statuses.append(
            {
                **source,
                "absolutePath": os.path.abspath(path),
                "exists": os.path.exists(path),
                "readable": os.access(path, os.R_OK),
            }
        )
    return statuses


def resolved_paths_for_command(command, line_mapping_path=None):
    if command.startswith("chamber"):
        return {
            "lineMappingPath": os.path.abspath(line_mapping_path or LINE_MAPPING_PATH),
        }
    return {}


def require_file(path):
    if not os.path.isfile(path):
        raise FileNotFoundError(f"파일이 없습니다: {path}")
    if not os.access(path, os.R_OK):
        raise PermissionError(f"파일을 읽을 권한이 없습니다: {path}")


def read_text_file(path):
    require_file(path)
    with open(path, "r", encoding="utf-8") as file:
        return file.read()


def read_parquet(path):
    require_file(path)
    try:
        import polars as pl

        return pl.read_parquet(path)
    except ImportError:
        try:
            import pandas as pd

            return pd.read_parquet(path)
        except ImportError as exc:
            raise RuntimeError("parquet 파일을 읽으려면 Python 패키지 polars 또는 pandas+pyarrow가 필요합니다.") from exc


def read_met_rows(path, device=CONFIG["device"]):
    require_file(path)

    with open(path, "r", encoding="utf-8") as file:
        lines = [line.rstrip("\n") for line in file]

    if not lines:
        return []

    header = [part.strip() for part in lines[0].split("\t")]
    rows = []
    for line in lines[1:]:
        values = [part.strip() for part in line.split("\t")]
        row = dict(zip(header, values))
        if device and "device" in row and row.get("device") and row.get("device") != device:
            continue
        row["main_step"] = strip_percent_prefix(row.get("main_step", ""))
        row["met_step"] = strip_percent_prefix(row.get("met_step", ""))
        rows.append(row)
    return rows


def read_tab_rows_from_text(content):
    lines = [line.rstrip("\r") for line in content.splitlines() if line.strip()]
    if not lines:
        return [], []

    header = [part.strip().lstrip("\ufeff") for part in lines[0].split("\t")]
    rows = []
    for line in lines[1:]:
        values = [part.strip() for part in line.split("\t")]
        rows.append({column: values[index] if index < len(values) else "" for index, column in enumerate(header)})
    return header, rows


def get_column_name(header, target):
    for column in header:
        if column == target:
            return column
    target_lower = target.lower()
    for column in header:
        if column.lower() == target_lower:
            return column
    return ""


def add_unique_text(values, value):
    text = str(value or "").strip()
    if text and text not in values:
        values.append(text)


def chamber_line_rows_from_text(content):
    header, raw_rows = read_tab_rows_from_text(content)
    warnings = []
    line_column = get_column_name(header, "line")
    line_code_column = get_column_name(header, "line_code")
    device_column = get_column_name(header, "device")
    missing_columns = [
        name
        for name, column in (
            ("line", line_column),
            ("line_code", line_code_column),
            ("device", device_column),
        )
        if not column
    ]

    if missing_columns:
        warnings.append(f"line_mapping.txt에서 필수 컬럼을 찾지 못했습니다: {', '.join(missing_columns)}")
        return [], len(raw_rows), warnings

    grouped = {}
    for row in raw_rows:
        line_name = str(row.get(line_column, "")).strip()
        if not line_name:
            continue

        current = grouped.setdefault(
            line_name,
            {
                "key": line_name,
                "lineName": line_name,
                "devices": [],
                "lineCodeValues": [],
                "deviceValues": [],
            },
        )
        line_code = str(row.get(line_code_column, "") or "").strip()
        device = str(row.get(device_column, "") or "").strip()
        add_unique_text(current["lineCodeValues"], line_code)
        add_unique_text(current["deviceValues"], device)
        if line_code and device:
            device_key = f"{line_code}::{device}"
            if not any(item["key"] == device_key for item in current["devices"]):
                current["devices"].append({"key": device_key, "lineCode": line_code, "device": device})

    rows = []
    for row in grouped.values():
        rows.append(
            {
                **row,
                "lineCode": ", ".join(row["lineCodeValues"]),
                "device": ", ".join(row["deviceValues"]),
            }
        )
    return rows, len(raw_rows), warnings


def chamber_data_sources(line_code, device):
    line_root = f"{CONFIG['eadsRoot']}/{line_code}"
    device_root = f"{line_root}/{device}"
    return [
        {
            "key": "chamber_met",
            "label": "개별챔버 MET 매핑",
            "path": f"{line_root}/met.txt",
        },
        {
            "key": "chamber_fail",
            "label": "개별챔버 중심치 이상목록",
            "path": f"{device_root}/fail_list.parquet",
        },
        {
            "key": "chamber_std",
            "label": "개별챔버 산포 이상목록",
            "path": f"{device_root}/fail_list_std.parquet",
        },
    ]


def command_chamber_lines(_args):
    line_mapping_path = LINE_MAPPING_PATH
    line_mapping_content = read_text_file(line_mapping_path)
    rows, input_row_count, warnings = chamber_line_rows_from_text(line_mapping_content)
    write_json(
        {
            "ok": True,
            "rows": rows,
            "sources": source_status(CHAMBER_DATA_SOURCES),
            "diagnostics": {
                "version": LOADER_VERSION,
                "resolvedPaths": resolved_paths_for_command("chamber-lines", line_mapping_path),
                "inputRows": {"line_mapping": input_row_count},
                "outputRows": len(rows),
                "warnings": warnings,
            },
        }
    )


def command_chamber_summary(args):
    line_code = str(args.line_code or "").strip()
    device = str(args.device or "").strip()
    if not line_code or not device:
        raise ValueError("lineCode와 device가 필요합니다.")

    sources = chamber_data_sources(line_code, device)
    diagnostics = {
        "version": LOADER_VERSION,
        "lineCode": line_code,
        "device": device,
        "inputRows": {},
        "columns": {},
        "usedRows": {},
        "outputRows": 0,
        "warnings": [],
    }
    met_source, fail_source, std_source = sources
    fail_rows = load_optional_parquet(fail_source, diagnostics)
    std_rows = load_optional_parquet(std_source, diagnostics)
    met_rows = load_optional_met_rows(met_source, diagnostics, device=device)

    by_main_step, _by_step_desc = met_lookup(met_rows)
    merged = {}
    key_prefix = f"chamber::{line_code}::{device}::"
    diagnostics["usedRows"]["fail"] = add_summary_rows(
        merged,
        fail_rows,
        "centerCount",
        by_main_step,
        data_kind="chamber",
        key_prefix=key_prefix,
        filter_cross_line_eqp=False,
    )
    diagnostics["usedRows"]["std"] = add_summary_rows(
        merged,
        std_rows,
        "stdCount",
        by_main_step,
        data_kind="chamber",
        key_prefix=key_prefix,
        filter_cross_line_eqp=False,
    )

    rows = [
        {
            **row,
            "lineCode": line_code,
            "device": device,
            "chartRoot": "chamber",
        }
        for row in merged.values()
        if row["centerCount"] != 0 or row["stdCount"] != 0
    ]
    rows.sort(key=lambda row: (row["mainStep"], row["metStep"]))
    diagnostics["outputRows"] = len(rows)

    if not fail_rows and not std_rows:
        write_json(
            {
                "ok": False,
                "error": "개별챔버 중심치/산포 이상 parquet에서 읽은 행이 없습니다. 파일 경로와 권한을 확인하세요.",
                "config": CONFIG,
                "sources": source_status(sources),
                "diagnostics": diagnostics,
                "rows": [],
            }
        )
        return

    write_json(
        {
            "ok": True,
            "config": CONFIG,
            "sources": source_status(sources),
            "diagnostics": diagnostics,
            "rows": rows,
        }
    )


def strip_percent_prefix(value):
    if "%" in value:
        return value.split("%", 1)[1]
    return value


def is_p4d_eqp(value):
    digits = "".join(ch if ch.isdigit() else " " for ch in str(value)).split()
    return any(token.startswith("35") for token in digits)


def frame_records(dataframe):
    if hasattr(dataframe, "to_dicts"):
        return dataframe.to_dicts()
    if hasattr(dataframe, "to_dict"):
        return dataframe.to_dict(orient="records")
    return list(dataframe)


def frame_columns(dataframe):
    return list(getattr(dataframe, "columns", []))


def frame_height(dataframe):
    return getattr(dataframe, "height", len(dataframe))


def is_polars_frame(dataframe):
    return dataframe.__class__.__module__.startswith("polars")


def sort_frame(dataframe, column):
    if column not in frame_columns(dataframe):
        return dataframe
    if is_polars_frame(dataframe):
        return dataframe.sort(column)
    return dataframe.sort_values(column)


def filter_frame_p3d_drawing(dataframe):
    eqp_columns = [column for column in ("eqp_id", "eqpid", "eqp_ch") if column in frame_columns(dataframe)]
    if not eqp_columns:
        return dataframe
    if is_polars_frame(dataframe):
        pl = load_polars()
        expression = None
        for column in eqp_columns:
            condition = (
                pl.col(column)
                .cast(pl.Utf8)
                .str.extract_all(r"\d+")
                .list.eval(pl.element().str.starts_with("35"))
                .list.any()
            )
            expression = condition if expression is None else expression | condition
        return dataframe.filter(~expression)

    mask = None
    for column in eqp_columns:
        condition = dataframe[column].astype(str).apply(is_p4d_eqp)
        mask = condition if mask is None else mask | condition
    return dataframe[~mask]


def filter_frame_eqp(dataframe, eqp_id):
    eqp_columns = [column for column in ("eqp_id", "eqpid", "eqp_ch") if column in frame_columns(dataframe)]
    if not eqp_columns:
        return dataframe
    target_eqp_id = str(eqp_id).strip()
    if is_polars_frame(dataframe):
        pl = load_polars()
        expression = None
        for column in eqp_columns:
            condition = pl.col(column).cast(pl.Utf8).fill_null("").str.strip_chars() == target_eqp_id
            expression = condition if expression is None else expression | condition
        return dataframe.filter(expression)

    mask = None
    for column in eqp_columns:
        condition = dataframe[column].astype(str).str.strip() == target_eqp_id
        mask = condition if mask is None else mask | condition
    return dataframe[mask]


def exclude_frame_eqp(dataframe, eqp_id):
    eqp_columns = [column for column in ("eqp_id", "eqpid", "eqp_ch") if column in frame_columns(dataframe)]
    if not eqp_columns:
        return dataframe
    target_eqp_id = str(eqp_id).strip()
    if is_polars_frame(dataframe):
        pl = load_polars()
        expression = None
        for column in eqp_columns:
            condition = pl.col(column).cast(pl.Utf8).fill_null("").str.strip_chars() != target_eqp_id
            expression = condition if expression is None else expression & condition
        return dataframe.filter(expression)

    mask = None
    for column in eqp_columns:
        condition = dataframe[column].astype(str).str.strip() != target_eqp_id
        mask = condition if mask is None else mask & condition
    return dataframe[mask]


def select_frame_columns(dataframe, columns):
    existing = [column for column in columns if column in frame_columns(dataframe)]
    if is_polars_frame(dataframe):
        return dataframe.select(existing)
    return dataframe[existing]


def rename_frame_column(dataframe, source, target):
    columns = frame_columns(dataframe)
    if source not in columns or target in columns:
        return dataframe
    if is_polars_frame(dataframe):
        return dataframe.rename({source: target})
    return dataframe.rename(columns={source: target})


def normalize_fcc_chart_frame(dataframe):
    return rename_frame_column(dataframe, "defect_value", "fab_value")


def split_p3d_drawing_df(dataframe):
    return filter_frame_p3d_drawing(dataframe)


def split_fcc_drawing_df(dataframe):
    return normalize_fcc_chart_frame(dataframe)


def records(dataframe):
    return frame_records(dataframe)


def column_values(dataframe, column):
    if column not in frame_columns(dataframe):
        return []
    if is_polars_frame(dataframe):
        return dataframe.select(column).to_series().to_list()
    return dataframe[column].tolist()


def is_missing_value(value):
    if value is None:
        return True
    try:
        return bool(value != value)
    except Exception:
        return False


def as_list(value):
    if is_missing_value(value):
        return []
    if hasattr(value, "tolist"):
        value = value.tolist()
    if isinstance(value, list):
        return [item for item in value if not is_missing_value(item)]
    if isinstance(value, tuple) or isinstance(value, set):
        return [item for item in value if not is_missing_value(item)]
    return [value]


def parse_eqp_ids(value):
    values = as_list(value)
    if len(values) == 1 and isinstance(values[0], str):
        raw = values[0].strip()
        if not raw:
            return []
        if raw.startswith("[") and raw.endswith("]"):
            try:
                values = as_list(ast.literal_eval(raw))
            except Exception:
                values = [raw]
        elif "," in raw:
            values = [part.strip() for part in raw.split(",")]

    return [str(item).strip() for item in values if str(item).strip()]


def get_first(row, names):
    for name in names:
        if name in row and not is_missing_value(row[name]):
            return row[name]
    return ""


def normalize_step(value):
    return strip_percent_prefix(str(value or "").strip())


def met_lookup(met_rows, step_normalizer=normalize_step):
    by_main_step = []
    by_step_desc = {}
    for row in met_rows:
        main_step = step_normalizer(row.get("main_step") or "")
        step_desc = row.get("step_desc") or ""
        sdwt = row.get("sdwt") or ""
        if main_step:
            by_main_step.append((main_step, step_desc, sdwt))
        if step_desc and step_desc not in by_step_desc:
            by_step_desc[step_desc] = sdwt
    return by_main_step, by_step_desc


def find_step_desc(main_seq, by_main_step):
    main_seq = normalize_step(main_seq)
    for main_step, step_desc, sdwt in by_main_step:
        main_step = normalize_step(main_step)
        if main_step and (main_step in main_seq or main_seq in main_step):
            return step_desc, sdwt
    return "", ""


def add_summary_rows(
    target,
    source_rows,
    count_key,
    by_main_step,
    main_columns=("main_seq", "대상스탭", "main_step", "mainStep"),
    met_columns=("met_seq", "계측스탭", "met_step", "metStep"),
    eqp_columns=("eqpid", "eqp_id", "eqpIds", "eqp_ids"),
    data_kind="",
    key_prefix="",
    filter_cross_line_eqp=True,
    allowed_keys=None,
    step_normalizer=normalize_step,
):
    eqp_ids_key = "centerEqpIds" if count_key == "centerCount" else "stdEqpIds"

    added = 0
    for row in source_rows:
        main_step_raw = str(get_first(row, main_columns) or "").strip()
        met_step_raw = str(get_first(row, met_columns) or "").strip()
        main_step = step_normalizer(main_step_raw)
        met_step = step_normalizer(met_step_raw)
        if not main_step or not met_step:
            continue

        key = f"{key_prefix}{main_step}::{met_step}"
        if allowed_keys is not None and key not in allowed_keys:
            continue
        step_desc, sdwt = find_step_desc(main_step, by_main_step)
        eqp_ids = parse_eqp_ids(get_first(row, eqp_columns))
        if filter_cross_line_eqp and ((CONFIG["selectLine"] == "PFB3" and CONFIG["device"] == "D1c") or CONFIG["selectLine"] == "P4D"):
            eqp_ids = [eqp_id for eqp_id in eqp_ids if not is_p4d_eqp(eqp_id)]
        if not eqp_ids:
            continue

        initial_row = {
            "key": key,
            "mainStep": main_step,
            "mainStepPath": main_step_raw or main_step,
            "stepSeq": main_step,
            "metStep": met_step,
            "metStepPath": met_step_raw or met_step,
            "stepDesc": step_desc,
            "sdwt": sdwt,
            "centerCount": 0,
            "stdCount": 0,
            "centerEqpIds": [],
            "stdEqpIds": [],
            "eqpIds": [],
        }
        if data_kind:
            initial_row["dataKind"] = data_kind

        current = target.setdefault(key, initial_row)

        if step_desc and not current["stepDesc"]:
            current["stepDesc"] = step_desc
        if sdwt and not current["sdwt"]:
            current["sdwt"] = sdwt

        current[eqp_ids_key] = sorted(set(current[eqp_ids_key]) | set(eqp_ids))
        current[count_key] = len(current[eqp_ids_key])
        current["eqpIds"] = sorted(set(current["eqpIds"]) | set(eqp_ids))
        added += 1

    return added


def add_fcc_met_rows(target, met_rows, key_prefix="fcc", chart_root="step", source_priority=1):
    added = 0
    for row in met_rows:
        main_step_raw = str(row.get("main_step") or "").strip()
        met_step_raw = str(row.get("met_step") or "").strip()
        main_step = fcc_mapping_step_code(main_step_raw)
        met_step = fcc_mapping_step_code(met_step_raw)
        if not main_step or not met_step:
            continue

        key = f"{key_prefix}::{main_step}::{met_step}"
        if key in target:
            continue

        target[key] = {
            "key": key,
            "dataKind": "fcc",
            "chartRoot": chart_root,
            "sourcePriority": source_priority,
            "mainStep": main_step,
            "mainStepPath": main_step_raw or main_step,
            "stepSeq": main_step,
            "metStep": met_step,
            "metStepPath": met_step_raw or met_step,
            "stepDesc": row.get("step_desc") or "",
            "sdwt": row.get("sdwt") or "",
            "centerCount": 0,
            "stdCount": 0,
            "centerEqpIds": [],
            "stdEqpIds": [],
            "eqpIds": [],
        }
        added += 1

    return added


def fcc_met_mapping_index(met_rows):
    by_key = {}
    by_main_step = {}

    for row in met_rows:
        main_step_raw = str(row.get("main_step") or "").strip()
        met_step_raw = str(row.get("met_step") or "").strip()
        main_step = fcc_mapping_step_code(main_step_raw)
        met_step = fcc_mapping_step_code(met_step_raw)
        if not main_step or not met_step:
            continue

        entry = {
            "mainStep": main_step,
            "mainStepPath": main_step_raw or main_step,
            "metStep": met_step,
            "metStepPath": met_step_raw or met_step,
            "stepDesc": row.get("step_desc") or "",
            "sdwt": row.get("sdwt") or "",
        }
        by_key[(main_step, met_step)] = entry
        by_main_step.setdefault(main_step, []).append(entry)

    return by_key, by_main_step


def add_fcc_summary_rows(
    target,
    source_rows,
    count_key,
    by_main_step,
    mapped_keys,
    eqp_columns,
    key_prefix="fcc",
    chart_root="step",
    source_priority=1,
    required_eqp_ids=None,
    met_mapping_by_key=None,
    met_mapping_by_main_step=None,
    use_mapping_met_step=False,
):
    eqp_ids_key = "centerEqpIds" if count_key == "centerCount" else "stdEqpIds"

    added = 0
    for row in source_rows:
        main_step_raw = str(get_first(row, ("main_seq",)) or "").strip()
        met_seq_raw = str(get_first(row, ("met_seq",)) or "").strip()
        main_step = fcc_mapping_step_code(main_step_raw)
        fail_met_step = fcc_mapping_step_code(met_seq_raw)
        item_id = fcc_item_id_from_met_seq(met_seq_raw)
        if not main_step or not fail_met_step or not item_id:
            continue

        mapped_entry = None
        if use_mapping_met_step:
            mapped_entry = (met_mapping_by_key or {}).get((main_step, fail_met_step))
            candidates = (met_mapping_by_main_step or {}).get(main_step, [])
            if mapped_entry is None and len(candidates) == 1:
                mapped_entry = candidates[0]
            if mapped_entry is None:
                continue

        met_step = mapped_entry["metStep"] if mapped_entry else fail_met_step
        mapping_key = f"{key_prefix}::{main_step}::{met_step}"
        if mapping_key not in mapped_keys:
            continue

        met_seq = f"{met_step}_{item_id}"
        key = f"{key_prefix}::{main_step}::{met_seq}"
        step_desc, sdwt = find_step_desc(main_step, by_main_step)
        if mapped_entry:
            main_step_raw = mapped_entry["mainStepPath"]
            met_seq_raw = met_seq
            step_desc = mapped_entry["stepDesc"] or step_desc
            sdwt = mapped_entry["sdwt"] or sdwt
        eqp_ids = parse_eqp_ids(get_first(row, eqp_columns))
        if required_eqp_ids is not None:
            eqp_ids = [eqp_id for eqp_id in eqp_ids if eqp_id in required_eqp_ids]
        if not eqp_ids:
            continue

        current = target.setdefault(
            key,
            {
                "key": key,
                "dataKind": "fcc",
                "chartRoot": chart_root,
                "sourcePriority": source_priority,
                "mainStep": main_step,
                "mainStepPath": main_step_raw or main_step,
                "stepSeq": main_step,
                "metStep": met_seq,
                "metStepPath": met_seq_raw or met_seq,
                "stepDesc": step_desc,
                "sdwt": sdwt,
                "centerCount": 0,
                "stdCount": 0,
                "centerEqpIds": [],
                "stdEqpIds": [],
                "eqpIds": [],
            },
        )

        if main_step_raw:
            current["mainStepPath"] = main_step_raw
        if met_seq_raw:
            current["metStepPath"] = met_seq_raw
        if step_desc and not current["stepDesc"]:
            current["stepDesc"] = step_desc
        if sdwt and not current["sdwt"]:
            current["sdwt"] = sdwt
        current["sourcePriority"] = min(current.get("sourcePriority", source_priority), source_priority)

        current[eqp_ids_key] = sorted(set(current[eqp_ids_key]) | set(eqp_ids))
        current[count_key] = len(current[eqp_ids_key])
        current["eqpIds"] = sorted(set(current["eqpIds"]) | set(eqp_ids))
        added += 1

    return added


def collect_eqp_ids(rows, eqp_columns=("eqpid",)):
    eqp_ids = set()
    for row in rows:
        eqp_ids.update(parse_eqp_ids(get_first(row, eqp_columns)))
    return eqp_ids


def fcc_met_unique_counts(met_rows):
    main_steps = set()
    met_steps = set()
    for row in met_rows:
        main_step = fcc_mapping_step_code(str(row.get("main_step") or "").strip())
        met_step = fcc_mapping_step_code(str(row.get("met_step") or "").strip())
        if main_step:
            main_steps.add(main_step)
        if met_step:
            met_steps.add(met_step)
    return {
        "extraMetMainStepCount": len(main_steps),
        "extraMetStepCount": len(met_steps),
    }


def load_optional_parquet(source, diagnostics):
    try:
        dataframe = read_parquet(source["path"])
        diagnostics["inputRows"][source["key"]] = frame_height(dataframe)
        diagnostics["columns"][source["key"]] = frame_columns(dataframe)
        return frame_records(dataframe)
    except Exception as exc:
        diagnostics["warnings"].append(f"{source['label']} 읽기 실패: {exc}")
        diagnostics["inputRows"][source["key"]] = 0
        diagnostics["columns"][source["key"]] = []
        return []


def load_optional_met_rows(source, diagnostics, device=CONFIG["device"]):
    try:
        rows = read_met_rows(source["path"], device=device)
        diagnostics["inputRows"][source["key"]] = len(rows)
        diagnostics["columns"][source["key"]] = list(rows[0].keys()) if rows else []
        return rows
    except Exception as exc:
        diagnostics["warnings"].append(f"{source['label']} 읽기 실패: {exc}")
        diagnostics["inputRows"][source["key"]] = 0
        diagnostics["columns"][source["key"]] = []
        return []


def command_summary(_args):
    diagnostics = {
        "version": LOADER_VERSION,
        "inputRows": {},
        "columns": {},
        "usedRows": {},
        "outputRows": 0,
        "warnings": [],
    }
    fail_rows = load_optional_parquet(DATA_SOURCES[1], diagnostics)
    std_rows = load_optional_parquet(DATA_SOURCES[2], diagnostics)
    met_rows = load_optional_met_rows(DATA_SOURCES[3], diagnostics)

    by_main_step, _by_step_desc = met_lookup(met_rows)
    merged = {}
    diagnostics["usedRows"]["fail"] = add_summary_rows(merged, fail_rows, "centerCount", by_main_step)
    diagnostics["usedRows"]["std"] = add_summary_rows(merged, std_rows, "stdCount", by_main_step)

    rows = [
        row
        for row in merged.values()
        if row["centerCount"] != 0 or row["stdCount"] != 0
    ]
    rows.sort(key=lambda row: (row["mainStep"], row["metStep"]))
    diagnostics["outputRows"] = len(rows)

    if not fail_rows and not std_rows:
        write_json(
            {
                "ok": False,
                "error": "중심치/산포 이상 parquet에서 읽은 행이 없습니다. 파일 경로, 권한, parquet 의존성을 확인하세요.",
                "config": CONFIG,
                "sources": source_status(),
                "diagnostics": diagnostics,
                "rows": [],
            }
        )
        return

    write_json(
        {
            "ok": True,
            "config": CONFIG,
            "sources": source_status(),
            "diagnostics": diagnostics,
            "rows": rows,
        }
    )


def command_fcc_summary(_args):
    diagnostics = {
        "version": LOADER_VERSION,
        "inputRows": {},
        "columns": {},
        "usedRows": {},
        "outputRows": 0,
        "warnings": [],
    }
    fcc_step_met_source = next(source for source in FCC_DATA_SOURCES if source["key"] == "fcc_step_met")
    fcc_fail_source = next(source for source in FCC_DATA_SOURCES if source["key"] == "fcc_fail")
    fcc_extra_met_source = next(source for source in FCC_DATA_SOURCES if source["key"] == "fcc_extra_met")
    fcc_extra_fail_source = next(source for source in FCC_DATA_SOURCES if source["key"] == "fcc_extra_fail")
    fcc_extra_std_source = next(source for source in FCC_DATA_SOURCES if source["key"] == "fcc_extra_std")
    fail_rows = load_optional_parquet(fcc_fail_source, diagnostics)
    met_rows = load_optional_met_rows(fcc_step_met_source, diagnostics, device=None)
    extra_fail_rows = load_optional_parquet(fcc_extra_fail_source, diagnostics)
    extra_std_rows = load_optional_parquet(fcc_extra_std_source, diagnostics)
    extra_met_rows = load_optional_met_rows(fcc_extra_met_source, diagnostics, device=None)

    by_main_step, _by_step_desc = met_lookup(met_rows, step_normalizer=fcc_mapping_step_code)
    fcc_center_eqp_ids = collect_eqp_ids(fail_rows, ("eqpid",))
    metrics = {
        **fcc_met_unique_counts(extra_met_rows),
        "centerEqpCount": len(fcc_center_eqp_ids),
    }
    merged = {}
    diagnostics["usedRows"]["fcc_step_met"] = add_fcc_met_rows(
        merged,
        met_rows,
        key_prefix="fcc_step",
        chart_root="step",
        source_priority=1,
    )
    mapped_keys = set(merged)
    diagnostics["usedRows"]["fcc_fail"] = add_fcc_summary_rows(
        merged,
        fail_rows,
        "centerCount",
        by_main_step,
        mapped_keys,
        eqp_columns=("eqpid",),
        key_prefix="fcc_step",
        chart_root="step",
        source_priority=1,
    )
    diagnostics["usedRows"]["fcc_extra_met"] = len(extra_met_rows)
    diagnostics["usedRows"]["fcc_extra_fail"] = sum(
        1
        for row in extra_fail_rows
        if set(parse_eqp_ids(get_first(row, ("eqpid",)))) & fcc_center_eqp_ids
    )
    diagnostics["usedRows"]["fcc_extra_std"] = sum(
        1
        for row in extra_std_rows
        if set(parse_eqp_ids(get_first(row, ("eqpid",)))) & fcc_center_eqp_ids
    )

    rows = [
        row
        for row in merged.values()
        if row["centerCount"] != 0
    ]
    rows.sort(key=lambda row: (row["mainStep"], row["metStep"]))
    diagnostics["outputRows"] = len(rows)

    if not met_rows and not fail_rows and not extra_met_rows and not extra_fail_rows and not extra_std_rows:
        write_json(
            {
                "ok": False,
                "error": "FCC 스탭 MET/중심치 또는 FCC 추가 파일에서 읽은 행이 없습니다. 파일 경로, 권한, 입력 컬럼을 확인하세요.",
                "config": CONFIG,
                "sources": source_status(FCC_DATA_SOURCES),
                "diagnostics": diagnostics,
                "metrics": metrics,
                "rows": [],
            }
        )
        return

    write_json(
        {
            "ok": True,
            "config": CONFIG,
            "sources": source_status(FCC_DATA_SOURCES),
            "diagnostics": diagnostics,
            "metrics": metrics,
            "rows": rows,
        }
    )


def latest_child_dir(path):
    if not os.path.isdir(path):
        raise FileNotFoundError(f"디렉터리가 없습니다: {path}")

    names = [
        name
        for name in os.listdir(path)
        if os.path.isdir(os.path.join(path, name))
    ]
    if not names:
        raise FileNotFoundError(f"하위 날짜 디렉터리가 없습니다: {path}")
    return sorted(names)[-1]


def unique_nonempty(values):
    result = []
    seen = set()
    for value in values:
        value = str(value or "").strip()
        if value and value not in seen:
            seen.add(value)
            result.append(value)
    return result


def strip_main_suffix(value):
    value = str(value or "").strip()
    while value.endswith("_main"):
        value = value[: -len("_main")]
    return value


def normalize_dir_key(value, is_met=False):
    value = normalize_step(value).lower()
    if is_met:
        value = strip_main_suffix(value)
    return value


def chart_met_step_candidates(chart_met_step):
    raw = normalize_step(chart_met_step)
    base = strip_main_suffix(raw)
    candidates = [raw, raw.replace("_main_main", "_main"), base]
    if IS_MAIN_LINE:
        candidates.append(f"{base}_main")
    return unique_nonempty(candidates)


def list_child_dirs(path):
    if not os.path.isdir(path):
        return []
    return sorted(
        name
        for name in os.listdir(path)
        if os.path.isdir(os.path.join(path, name))
    )


def resolve_child_dir(parent, candidates, label, is_met=False):
    attempts = [os.path.join(parent, candidate) for candidate in candidates]
    for attempt in attempts:
        if os.path.isdir(attempt):
            return attempt, os.path.basename(attempt), attempts

    children = list_child_dirs(parent)
    if not children:
        raise FileNotFoundError(
            f"{label} 디렉터리가 없습니다: {parent}. 시도한 경로: {', '.join(attempts[:5])}"
        )

    candidate_keys = {normalize_dir_key(candidate, is_met=is_met) for candidate in candidates}
    for child in children:
        if normalize_dir_key(child, is_met=is_met) in candidate_keys:
            return os.path.join(parent, child), child, attempts

    for child in children:
        child_key = normalize_dir_key(child, is_met=is_met)
        if any(key and (key in child_key or child_key in key) for key in candidate_keys):
            return os.path.join(parent, child), child, attempts

    raise FileNotFoundError(
        f"{label} 디렉터리를 찾지 못했습니다. 시도: {', '.join(candidates[:6])}. "
        f"사용 가능 예: {', '.join(children[:8])}"
    )


def resolve_parquet_file(data_dir, prefix, main_candidates):
    exact_names = [f"{prefix}_{candidate}.parquet" for candidate in main_candidates]
    for name in exact_names:
        path = os.path.join(data_dir, name)
        if os.path.isfile(path):
            return path, exact_names

    if not os.path.isdir(data_dir):
        raise FileNotFoundError(f"날짜 데이터 디렉터리가 없습니다: {data_dir}")

    parquet_files = sorted(
        name
        for name in os.listdir(data_dir)
        if name.startswith(f"{prefix}_") and name.endswith(".parquet")
    )
    if parquet_files:
        return os.path.join(data_dir, parquet_files[0]), exact_names

    raise FileNotFoundError(
        f"{prefix} parquet 파일을 찾지 못했습니다: {data_dir}. "
        f"시도: {', '.join(exact_names[:5])}. 사용 가능 파일 예: {', '.join(sorted(os.listdir(data_dir))[:8])}"
    )


def resolve_chart_paths(main_step, chart_met_step):
    main_candidates = unique_nonempty([main_step, normalize_step(main_step)])
    main_dir, main_dir_name, main_attempts = resolve_child_dir(FOLDER_PATH, main_candidates, "main_step")

    met_candidates = chart_met_step_candidates(chart_met_step)
    met_dir, met_dir_name, met_attempts = resolve_child_dir(main_dir, met_candidates, "met_step", is_met=True)

    latest_date = latest_child_dir(met_dir)
    data_dir = os.path.join(met_dir, latest_date)
    main_file_candidates = unique_nonempty([main_dir_name, main_step, normalize_step(main_step)])
    all_prefix = "main_all" if IS_MAIN_LINE else "all"
    fail_prefix = "main_fail" if IS_MAIN_LINE else "fail"
    std_prefix = "main_fail_std" if IS_MAIN_LINE else "fail_std"
    all_path, all_attempts = resolve_parquet_file(data_dir, all_prefix, main_file_candidates)
    fail_path, fail_attempts = resolve_parquet_file(data_dir, fail_prefix, main_file_candidates)
    try:
        std_path, std_attempts = resolve_parquet_file(data_dir, std_prefix, main_file_candidates)
    except FileNotFoundError:
        std_path = None
        std_attempts = [f"{std_prefix}_{candidate}.parquet" for candidate in main_file_candidates]

    return {
        "mainDir": main_dir,
        "metDir": met_dir,
        "dataDir": data_dir,
        "latestDate": latest_date,
        "allPath": all_path,
        "failPath": fail_path,
        "stdPath": std_path,
        "requested": {
            "mainStep": main_step,
            "chartMetStep": chart_met_step,
        },
        "resolved": {
            "mainStep": main_dir_name,
            "chartMetStep": met_dir_name,
        },
        "attempts": {
            "mainDirs": main_attempts,
            "metDirs": met_attempts,
            "allFiles": all_attempts,
            "failFiles": fail_attempts,
            "stdFiles": std_attempts,
        },
    }


def generic_item_id_from_met_step(value):
    text = strip_main_suffix(normalize_step(value)).strip()
    if "_" not in text:
        return ""
    item_id = text.split("_", 1)[1].split("_", 1)[0].strip()
    digits = "".join(char for char in item_id if char.isdigit())
    return digits or item_id


def resolve_chamber_chart_paths(line_code, device, main_step, chart_met_step):
    line_code = str(line_code or "").strip()
    device = str(device or "").strip()
    if not line_code or not device:
        raise ValueError("개별챔버 chart 경로에 필요한 lineCode/device가 없습니다.")

    root_path = f"{CONFIG['eadsRoot']}/{line_code}/{device}"
    main_candidates = unique_nonempty([main_step, normalize_step(main_step)])
    main_dir, main_dir_name, main_attempts = resolve_child_dir(root_path, main_candidates, "chamber main_step")

    met_candidates = unique_nonempty([normalize_step(chart_met_step), chart_met_step])
    met_dir, met_dir_name, met_attempts = resolve_child_dir(main_dir, met_candidates, "chamber met_step", is_met=True)

    latest_date = latest_child_dir(met_dir)
    data_dir = os.path.join(met_dir, latest_date)
    main_file_candidates = unique_nonempty([main_dir_name, main_step, normalize_step(main_step)])
    all_path, all_attempts = resolve_parquet_file(data_dir, "all", main_file_candidates)
    fail_path, fail_attempts = resolve_parquet_file(data_dir, "fail", main_file_candidates)
    try:
        std_path, std_attempts = resolve_parquet_file(data_dir, "fail_std", main_file_candidates)
    except FileNotFoundError:
        std_path = None
        std_attempts = [f"fail_std_{candidate}.parquet" for candidate in main_file_candidates]

    return {
        "rootPath": root_path,
        "mainDir": main_dir,
        "metDir": met_dir,
        "dataDir": data_dir,
        "latestDate": latest_date,
        "allPath": all_path,
        "failPath": fail_path,
        "stdPath": std_path,
        "requested": {
            "lineCode": line_code,
            "device": device,
            "mainStep": main_step,
            "chartMetStep": chart_met_step,
        },
        "resolved": {
            "lineCode": line_code,
            "device": device,
            "mainStep": main_dir_name,
            "chartMetStep": met_dir_name,
            "itemId": generic_item_id_from_met_step(chart_met_step),
        },
        "attempts": {
            "mainDirs": main_attempts,
            "metDirs": met_attempts,
            "allFiles": all_attempts,
            "failFiles": fail_attempts,
            "stdFiles": std_attempts,
        },
    }


def strip_fcc_prefix(value):
    value = str(value or "").strip()
    return value[4:] if value.lower().startswith("fcc_") else value


def fcc_mapping_step_code(value):
    text = strip_fcc_prefix(strip_main_suffix(normalize_step(value))).strip()
    head = text.split("_", 1)[0]
    digits = "".join(char for char in head if char.isdigit())
    if len(digits) >= 6:
        return digits[-6:]
    return digits or head


def fcc_item_id_from_met_seq(value):
    text = strip_fcc_prefix(strip_main_suffix(normalize_step(value))).strip()
    if "_" not in text:
        return ""
    tail = text.split("_", 1)[1]
    item_id = tail.split("_", 1)[0].strip()
    digits = "".join(char for char in item_id if char.isdigit())
    return digits or item_id


def normalize_item_id(value):
    if is_missing_value(value):
        return ""
    text = str(value or "").strip()
    digits = "".join(char for char in text if char.isdigit())
    return digits or text


def clean_text(value):
    if is_missing_value(value):
        return ""
    return str(value or "").strip()


def item_desc_for_item_id(dataframe, item_id):
    columns = frame_columns(dataframe)
    if "item_desc" not in columns:
        return ""

    descriptions = column_values(dataframe, "item_desc")
    if "item_id" in columns:
        target = normalize_item_id(item_id)
        for current_item_id, description in zip(column_values(dataframe, "item_id"), descriptions):
            if normalize_item_id(current_item_id) != target:
                continue
            text = clean_text(description)
            if text:
                return text
        return ""

    unique_descriptions = unique_nonempty(clean_text(description) for description in descriptions)
    return unique_descriptions[0] if len(unique_descriptions) == 1 else ""


def fcc_item_id_for_met_seq(met_seq):
    item_id = fcc_item_id_from_met_seq(met_seq)
    if not item_id:
        met_step_code = fcc_mapping_step_code(met_seq)
        raise ValueError(f"FCC met_seq {met_seq}에서 item_id를 찾지 못했습니다. 예: {met_step_code}_26")
    return item_id


def resolve_fcc_met_dir(main_dir, met_candidates, item_id, chart_root):
    try:
        return resolve_child_dir(main_dir, met_candidates, "fcc met_step", is_met=True)
    except FileNotFoundError:
        if chart_root != "root":
            raise

        children = list_child_dirs(main_dir)
        item_suffix = f"_{str(item_id).lower()}"
        fallback_matches = [
            child
            for child in children
            if normalize_dir_key(child, is_met=True).endswith(item_suffix)
        ]
        if not fallback_matches:
            raise

        fallback_name = fallback_matches[0]
        attempts = [os.path.join(main_dir, candidate) for candidate in met_candidates]
        attempts.extend(os.path.join(main_dir, match) for match in fallback_matches)
        return os.path.join(main_dir, fallback_name), fallback_name, attempts


def resolve_fcc_chart_paths(main_step, chart_met_step, chart_root="step", require_fail=True, resolve_std=True, require_std=False):
    main_step_code = fcc_mapping_step_code(main_step)
    met_step_code = fcc_mapping_step_code(chart_met_step)
    if not main_step_code or not met_step_code:
        raise ValueError(f"FCC chart 경로에 필요한 main_step/met_step이 없습니다: {main_step}, {chart_met_step}")

    item_id = fcc_item_id_for_met_seq(chart_met_step)
    root_path = FCC_FOLDER_PATH if chart_root == "root" else FCC_STEP_PATH
    main_candidates = unique_nonempty([f"U%{main_step_code}", main_step, main_step_code])
    main_dir, main_dir_name, main_attempts = resolve_child_dir(root_path, main_candidates, "fcc main_step")
    met_candidates = unique_nonempty([f"{met_step_code}_{item_id}"])
    met_dir, met_dir_name, met_attempts = resolve_fcc_met_dir(main_dir, met_candidates, item_id, chart_root)
    latest_date = latest_child_dir(met_dir)
    data_dir = os.path.join(met_dir, latest_date)
    file_candidates = unique_nonempty([f"U%{main_step_code}", main_dir_name, main_step])
    all_path, all_attempts = resolve_parquet_file(data_dir, "all", file_candidates)
    try:
        fail_path, fail_attempts = resolve_parquet_file(data_dir, "fail", file_candidates)
    except FileNotFoundError:
        if require_fail:
            raise
        fail_path = None
        fail_attempts = [f"fail_{candidate}.parquet" for candidate in file_candidates]
    if resolve_std:
        try:
            std_path, std_attempts = resolve_parquet_file(data_dir, "fail_std", file_candidates)
        except FileNotFoundError:
            if require_std:
                raise
            std_path = None
            std_attempts = [f"fail_std_{candidate}.parquet" for candidate in file_candidates]
    else:
        std_path = None
        std_attempts = []

    return {
        "mainDir": main_dir,
        "metDir": met_dir,
        "dataDir": data_dir,
        "latestDate": latest_date,
        "allPath": all_path,
        "failPath": fail_path,
        "stdPath": std_path,
        "requested": {
            "mainStep": main_step,
            "chartMetStep": chart_met_step,
            "chartRoot": chart_root,
        },
        "resolved": {
            "mainStep": main_dir_name,
            "chartMetStep": met_dir_name,
            "mainStepCode": main_step_code,
            "metStepCode": met_step_code,
            "itemId": item_id,
        },
        "attempts": {
            "mainDirs": main_attempts,
            "metDirs": met_attempts,
            "allFiles": all_attempts,
            "failFiles": fail_attempts,
            "stdFiles": std_attempts,
        },
    }


def sample_records(dataframe, limit=900):
    if limit is None:
        return records(dataframe)
    height = frame_height(dataframe)
    if height <= limit:
        return records(dataframe)
    if limit <= 1:
        indices = [0]
    else:
        indices = sorted({round(index * (height - 1) / (limit - 1)) for index in range(limit)})
    if is_polars_frame(dataframe):
        pl = load_polars()
        sample_index = "__sample_index"
        return records(dataframe.with_row_index(sample_index).filter(pl.col(sample_index).is_in(indices)).drop(sample_index))
    return records(dataframe.iloc[indices])


def add_time_fields(rows, column):
    for row in rows:
        value = row.get(column)
        row[f"{column}_text"] = time_text(value)
        row[f"{column}_ms"] = time_ms(value)
    return rows


def select_columns(dataframe):
    wanted = [
        "tkout_time",
        "fab_value",
        "process_id",
        "wafer_id",
        "lot_id",
        "lot_wf",
        "step_seq",
        "eqp_ch",
        "eqp_id",
        "eqpid",
        "item_id",
        "item_desc",
        "final_decision",
        "std_result",
    ]
    return select_frame_columns(dataframe, wanted)


def chart_records(dataframe, limit=900, anomaly_type=None):
    rows = add_time_fields(sample_records(select_columns(dataframe), limit), "tkout_time")
    if anomaly_type:
        for row in rows:
            row["anomaly_type"] = anomaly_type
    return rows


def numeric_domain(values):
    if not values:
        return None
    return {"min": min(values), "max": max(values)}


def numeric_column_values(dataframe, column):
    values = []
    for value in column_values(dataframe, column):
        try:
            number = float(value)
        except (TypeError, ValueError):
            continue
        if math.isfinite(number):
            values.append(number)
    return values


def percentile(sorted_values, ratio):
    if not sorted_values:
        return None
    if len(sorted_values) == 1:
        return sorted_values[0]
    position = (len(sorted_values) - 1) * ratio
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return sorted_values[lower]
    weight = position - lower
    return sorted_values[lower] * (1 - weight) + sorted_values[upper] * weight


def outlier_filtered_values(values):
    if len(values) < 4:
        return values

    sorted_values = sorted(values)
    q1 = percentile(sorted_values, 0.1)
    q3 = percentile(sorted_values, 0.9)
    iqr = q3 - q1
    if iqr <= 0:
        return values

    lower = q1 - iqr * 1.5
    upper = q3 + iqr * 1.5
    filtered = [value for value in values if lower <= value <= upper]
    return filtered or values


def outlier_display_domain(values):
    filtered = outlier_filtered_values(values)
    if not filtered:
        return None
    return {"min": min(filtered) - 2, "max": max(filtered) * 1.2}


def time_domain(dataframe, column):
    values = [value for value in (time_ms(value) for value in column_values(dataframe, column)) if value is not None]
    if not values:
        return None
    return {"min": min(values), "max": max(values)}


def command_chart(args):
    resolved_paths = resolve_chart_paths(args.main_step, args.chart_met_step)
    all_path = resolved_paths["allPath"]
    fail_path = resolved_paths["failPath"]
    std_path = resolved_paths["stdPath"]

    all_df = split_p3d_drawing_df(read_parquet(all_path))
    fail_df = split_p3d_drawing_df(read_parquet(fail_path))
    std_df = split_p3d_drawing_df(read_parquet(std_path)) if std_path else fail_df.head(0)

    all_df = sort_frame(all_df, "tkout_time")
    fail_df = sort_frame(fail_df, "tkout_time")
    std_df = sort_frame(std_df, "tkout_time")
    all_background = exclude_frame_eqp(all_df, args.eqp_id)
    fail_for_eqp = filter_frame_eqp(fail_df, args.eqp_id)
    std_for_eqp = filter_frame_eqp(std_df, args.eqp_id)
    main_all_fab_values = numeric_column_values(all_df, "fab_value")
    chart_fab_values_center = main_all_fab_values + numeric_column_values(fail_for_eqp, "fab_value")
    chart_fab_values_std = main_all_fab_values + numeric_column_values(std_for_eqp, "fab_value")
    chart_fab_values = chart_fab_values_center + numeric_column_values(std_for_eqp, "fab_value")

    pm_events = []
    if os.path.isfile(CONFIG["pmCodePath"]) and os.access(CONFIG["pmCodePath"], os.R_OK):
        pm_df = read_parquet(CONFIG["pmCodePath"])
        if {"asset", "inprg_dt", "work_type"}.issubset(set(frame_columns(pm_df))):
            if is_polars_frame(pm_df):
                pl = load_polars()
                pm_df = pm_df.with_columns(pl.col("asset").cast(pl.Utf8).str.replace_all("-", "_").alias("asset"))
                pm_df = pm_df.filter(pl.col("asset").str.contains(str(args.eqp_id), literal=True))
                pm_events = add_time_fields(records(pm_df.select(["asset", "inprg_dt", "work_type"]).head(80)), "inprg_dt")
            else:
                pm_df = pm_df.copy()
                pm_df["asset"] = pm_df["asset"].astype(str).str.replace("-", "_", regex=False)
                pm_df = pm_df[pm_df["asset"].str.contains(str(args.eqp_id), regex=False, na=False)]
                pm_events = add_time_fields(records(pm_df[["asset", "inprg_dt", "work_type"]].head(80)), "inprg_dt")

    write_json(
        {
            "ok": True,
            "diagnostics": {
                "version": LOADER_VERSION,
                "resolvedPaths": resolved_paths,
                "inputRows": {
                    "all": frame_height(all_df),
                    "allBackground": frame_height(all_background),
                    "fail": frame_height(fail_df),
                    "failForEqp": frame_height(fail_for_eqp),
                    "std": frame_height(std_df),
                    "stdForEqp": frame_height(std_for_eqp),
                },
            },
            "paths": {
                "all": all_path,
                "fail": fail_path,
                "std": std_path,
                "pm": CONFIG["pmCodePath"],
            },
            "latestDate": resolved_paths["latestDate"],
            "domains": {
                "x": time_domain(all_df, "tkout_time"),
                "yFull": numeric_domain(chart_fab_values),
                "yInitial": outlier_display_domain(main_all_fab_values),
                "center": {
                    "yFull": numeric_domain(chart_fab_values_center),
                    "yInitial": outlier_display_domain(main_all_fab_values),
                },
                "std": {
                    "yFull": numeric_domain(chart_fab_values_std),
                    "yInitial": outlier_display_domain(main_all_fab_values),
                },
            },
            "allPoints": chart_records(all_background, None),
            "failPoints": chart_records(fail_for_eqp, None, "center"),
            "stdPoints": chart_records(std_for_eqp, None, "std"),
            "pmEvents": pm_events,
        }
    )


def generic_chart_payload(resolved_paths, eqp_id, include_pm=True):
    all_path = resolved_paths["allPath"]
    fail_path = resolved_paths["failPath"]
    std_path = resolved_paths["stdPath"]

    all_df = sort_frame(read_parquet(all_path), "tkout_time")
    fail_df = sort_frame(read_parquet(fail_path), "tkout_time")
    std_df = sort_frame(read_parquet(std_path), "tkout_time") if std_path else fail_df.head(0)

    all_background = exclude_frame_eqp(all_df, eqp_id)
    fail_for_eqp = filter_frame_eqp(fail_df, eqp_id)
    std_for_eqp = filter_frame_eqp(std_df, eqp_id)
    all_fab_values = numeric_column_values(all_df, "fab_value")
    chart_fab_values_center = all_fab_values + numeric_column_values(fail_for_eqp, "fab_value")
    chart_fab_values_std = all_fab_values + numeric_column_values(std_for_eqp, "fab_value")
    chart_fab_values = chart_fab_values_center + numeric_column_values(std_for_eqp, "fab_value")

    return {
        "ok": True,
        "diagnostics": {
            "version": LOADER_VERSION,
            "resolvedPaths": resolved_paths,
            "inputRows": {
                "all": frame_height(all_df),
                "allBackground": frame_height(all_background),
                "fail": frame_height(fail_df),
                "failForEqp": frame_height(fail_for_eqp),
                "std": frame_height(std_df),
                "stdForEqp": frame_height(std_for_eqp),
            },
        },
        "paths": {
            "all": all_path,
            "fail": fail_path,
            "std": std_path,
            "pm": CONFIG["pmCodePath"] if include_pm else None,
        },
        "latestDate": resolved_paths["latestDate"],
        "itemDesc": item_desc_for_item_id(all_df, resolved_paths.get("resolved", {}).get("itemId", "")),
        "domains": {
            "x": time_domain(all_df, "tkout_time"),
            "yFull": numeric_domain(chart_fab_values),
            "yInitial": outlier_display_domain(all_fab_values),
            "center": {
                "yFull": numeric_domain(chart_fab_values_center),
                "yInitial": outlier_display_domain(all_fab_values),
            },
            "std": {
                "yFull": numeric_domain(chart_fab_values_std),
                "yInitial": outlier_display_domain(all_fab_values),
            },
        },
        "allPoints": chart_records(all_background, None),
        "failPoints": chart_records(fail_for_eqp, None, "center"),
        "stdPoints": chart_records(std_for_eqp, None, "std"),
        "pmEvents": pm_events_for_eqp(eqp_id) if include_pm else [],
    }


def command_chamber_chart(args):
    resolved_paths = resolve_chamber_chart_paths(args.line_code, args.device, args.main_step, args.chart_met_step)
    write_json(generic_chart_payload(resolved_paths, args.eqp_id, include_pm=True))


def pm_events_for_eqp(eqp_id):
    if not os.path.isfile(CONFIG["pmCodePath"]) or not os.access(CONFIG["pmCodePath"], os.R_OK):
        return []

    pm_df = read_parquet(CONFIG["pmCodePath"])
    if not {"asset", "inprg_dt", "work_type"}.issubset(set(frame_columns(pm_df))):
        return []

    if is_polars_frame(pm_df):
        pl = load_polars()
        pm_df = pm_df.with_columns(pl.col("asset").cast(pl.Utf8).str.replace_all("-", "_").alias("asset"))
        pm_df = pm_df.filter(pl.col("asset").str.contains(str(eqp_id), literal=True))
        return add_time_fields(records(pm_df.select(["asset", "inprg_dt", "work_type"]).head(80)), "inprg_dt")

    pm_df = pm_df.copy()
    pm_df["asset"] = pm_df["asset"].astype(str).str.replace("-", "_", regex=False)
    pm_df = pm_df[pm_df["asset"].str.contains(str(eqp_id), regex=False, na=False)]
    return add_time_fields(records(pm_df[["asset", "inprg_dt", "work_type"]].head(80)), "inprg_dt")


def fcc_chart_payload(resolved_paths, eqp_id, include_center=True, include_std=True, include_pm=True, require_std=False):
    all_path = resolved_paths["allPath"]
    fail_path = resolved_paths["failPath"]
    std_path = resolved_paths["stdPath"]

    all_df = split_fcc_drawing_df(read_parquet(all_path))
    if include_center:
        if not fail_path:
            raise FileNotFoundError(f"FCC fail parquet 파일을 찾지 못했습니다: {resolved_paths.get('dataDir', '')}")
        fail_df = split_fcc_drawing_df(read_parquet(fail_path))
    else:
        fail_df = all_df.head(0)
    if include_std and std_path:
        std_df = split_fcc_drawing_df(read_parquet(std_path))
    elif include_std and require_std:
        raise FileNotFoundError(f"FCC fail_std parquet 파일을 찾지 못했습니다: {resolved_paths.get('dataDir', '')}")
    else:
        std_df = all_df.head(0)

    all_df = sort_frame(all_df, "tkout_time")
    fail_df = sort_frame(fail_df, "tkout_time")
    std_df = sort_frame(std_df, "tkout_time")
    all_background = exclude_frame_eqp(all_df, eqp_id)
    fail_for_eqp = filter_frame_eqp(fail_df, eqp_id)
    std_for_eqp = filter_frame_eqp(std_df, eqp_id)
    all_fab_values = numeric_column_values(all_df, "fab_value")
    chart_fab_values_center = all_fab_values + numeric_column_values(fail_for_eqp, "fab_value")
    chart_fab_values_std = all_fab_values + numeric_column_values(std_for_eqp, "fab_value")
    chart_fab_values = chart_fab_values_center + numeric_column_values(std_for_eqp, "fab_value")

    return {
        "ok": True,
        "diagnostics": {
            "version": LOADER_VERSION,
            "resolvedPaths": resolved_paths,
            "inputRows": {
                "all": frame_height(all_df),
                "allBackground": frame_height(all_background),
                "fail": frame_height(fail_df),
                "failForEqp": frame_height(fail_for_eqp),
                "std": frame_height(std_df),
                "stdForEqp": frame_height(std_for_eqp),
            },
        },
        "paths": {
            "all": all_path,
            "fail": fail_path if include_center else None,
            "std": std_path if include_std else None,
            "pm": CONFIG["pmCodePath"] if include_pm else None,
        },
        "latestDate": resolved_paths["latestDate"],
        "itemDesc": item_desc_for_item_id(all_df, resolved_paths.get("resolved", {}).get("itemId", "")),
        "domains": {
            "x": time_domain(all_df, "tkout_time"),
            "yFull": numeric_domain(chart_fab_values),
            "yInitial": outlier_display_domain(all_fab_values),
            "center": {
                "yFull": numeric_domain(chart_fab_values_center),
                "yInitial": outlier_display_domain(all_fab_values),
            },
            "std": {
                "yFull": numeric_domain(chart_fab_values_std),
                "yInitial": outlier_display_domain(all_fab_values),
            },
        },
        "allPoints": chart_records(all_background, None),
        "failPoints": chart_records(fail_for_eqp, None, "center"),
        "stdPoints": chart_records(std_for_eqp, None, "std"),
        "pmEvents": pm_events_for_eqp(eqp_id) if include_pm else [],
    }


def fcc_extra_chart_specs_for_eqp(eqp_id, source_key="fcc_extra_fail", anomaly_type="center"):
    extra_met_source = next(source for source in FCC_DATA_SOURCES if source["key"] == "fcc_extra_met")
    extra_source = next(source for source in FCC_DATA_SOURCES if source["key"] == source_key)
    fcc_fail_source = next(source for source in FCC_DATA_SOURCES if source["key"] == "fcc_fail")
    is_std = anomaly_type == "std"

    try:
        fcc_fail_rows = frame_records(read_parquet(fcc_fail_source["path"]))
        if eqp_id not in collect_eqp_ids(fcc_fail_rows, ("eqpid",)):
            return []
        extra_rows = frame_records(read_parquet(extra_source["path"]))
        extra_met_rows = read_met_rows(extra_met_source["path"], device=None)
    except Exception:
        return []

    extra_met_by_key, extra_met_by_main_step = fcc_met_mapping_index(extra_met_rows)
    specs = []
    seen = set()
    for row in extra_rows:
        if eqp_id not in parse_eqp_ids(get_first(row, ("eqpid",))):
            continue

        main_step_raw = str(get_first(row, ("main_seq",)) or "").strip()
        met_seq_raw = str(get_first(row, ("met_seq",)) or "").strip()
        main_step = fcc_mapping_step_code(main_step_raw)
        fail_met_step = fcc_mapping_step_code(met_seq_raw)
        item_id = fcc_item_id_from_met_seq(met_seq_raw)
        if not main_step or not fail_met_step or not item_id:
            continue

        mapped_entry = extra_met_by_key.get((main_step, fail_met_step))
        candidates = extra_met_by_main_step.get(main_step, [])
        if mapped_entry is None and len(candidates) == 1:
            mapped_entry = candidates[0]
        if mapped_entry is None:
            continue

        met_seq = f"{mapped_entry['metStep']}_{item_id}"
        key = (mapped_entry["mainStepPath"], met_seq)
        if key in seen:
            continue
        seen.add(key)

        specs.append(
            {
                "key": f"fcc_extra_{anomaly_type}::{mapped_entry['mainStep']}::{met_seq}",
                "dataKind": "fcc",
                "chartRoot": "root",
                "sourcePriority": 0,
                "mainStep": mapped_entry["mainStep"],
                "mainStepPath": mapped_entry["mainStepPath"],
                "stepSeq": mapped_entry["mainStep"],
                "metStep": met_seq,
                "metStepPath": met_seq,
                "stepDesc": mapped_entry["stepDesc"],
                "sdwt": mapped_entry["sdwt"],
                "centerCount": 0 if is_std else 1,
                "stdCount": 1 if is_std else 0,
                "centerEqpIds": [] if is_std else [eqp_id],
                "stdEqpIds": [eqp_id] if is_std else [],
                "eqpIds": [eqp_id],
            }
        )
    return specs


def fcc_extra_center_charts(eqp_id):
    charts = []
    for spec in fcc_extra_chart_specs_for_eqp(eqp_id, source_key="fcc_extra_fail", anomaly_type="center"):
        try:
            resolved_paths = resolve_fcc_chart_paths(spec["mainStepPath"], spec["metStepPath"], "root", resolve_std=False)
            payload = fcc_chart_payload(resolved_paths, eqp_id, include_center=True, include_std=False, include_pm=False)
            payload["row"] = spec
            charts.append(payload)
        except Exception as exc:
            charts.append(
                {
                    "ok": False,
                    "row": spec,
                    "error": str(exc),
                    "paths": {},
                    "diagnostics": {"version": LOADER_VERSION},
                }
            )
    return charts


def fcc_extra_std_charts(eqp_id):
    charts = []
    for spec in fcc_extra_chart_specs_for_eqp(eqp_id, source_key="fcc_extra_std", anomaly_type="std"):
        try:
            resolved_paths = resolve_fcc_chart_paths(
                spec["mainStepPath"],
                spec["metStepPath"],
                "root",
                require_fail=False,
                resolve_std=True,
                require_std=True,
            )
            payload = fcc_chart_payload(
                resolved_paths,
                eqp_id,
                include_center=False,
                include_std=True,
                include_pm=False,
                require_std=True,
            )
            payload["row"] = spec
            charts.append(payload)
        except Exception as exc:
            charts.append(
                {
                    "ok": False,
                    "row": spec,
                    "error": str(exc),
                    "paths": {},
                    "diagnostics": {"version": LOADER_VERSION},
                }
            )
    return charts


def command_fcc_chart(args):
    resolved_paths = resolve_fcc_chart_paths(args.main_step, args.chart_met_step, args.chart_root, resolve_std=False)
    payload = fcc_chart_payload(resolved_paths, args.eqp_id, include_center=True, include_std=False, include_pm=True)
    payload["extraCenterCharts"] = fcc_extra_center_charts(args.eqp_id) if args.chart_root == "step" else []
    payload["extraStdCharts"] = fcc_extra_std_charts(args.eqp_id) if args.chart_root == "step" else []
    write_json(payload)


def main():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("summary")
    subparsers.add_parser("fcc-summary")
    subparsers.add_parser("chamber-lines")
    chamber_summary_parser = subparsers.add_parser("chamber-summary")
    chamber_summary_parser.add_argument("--line-code", required=True)
    chamber_summary_parser.add_argument("--device", required=True)
    chart_parser = subparsers.add_parser("chart")
    chart_parser.add_argument("--main-step", required=True)
    chart_parser.add_argument("--chart-met-step", required=True)
    chart_parser.add_argument("--eqp-id", required=True)
    chamber_chart_parser = subparsers.add_parser("chamber-chart")
    chamber_chart_parser.add_argument("--line-code", required=True)
    chamber_chart_parser.add_argument("--device", required=True)
    chamber_chart_parser.add_argument("--main-step", required=True)
    chamber_chart_parser.add_argument("--chart-met-step", required=True)
    chamber_chart_parser.add_argument("--eqp-id", required=True)
    fcc_chart_parser = subparsers.add_parser("fcc-chart")
    fcc_chart_parser.add_argument("--main-step", required=True)
    fcc_chart_parser.add_argument("--chart-met-step", required=True)
    fcc_chart_parser.add_argument("--eqp-id", required=True)
    fcc_chart_parser.add_argument("--chart-root", choices=("step", "root"), default="step")
    args = parser.parse_args()

    try:
        if args.command == "summary":
            command_summary(args)
        elif args.command == "fcc-summary":
            command_fcc_summary(args)
        elif args.command == "chamber-lines":
            command_chamber_lines(args)
        elif args.command == "chamber-summary":
            command_chamber_summary(args)
        elif args.command == "chart":
            command_chart(args)
        elif args.command == "chamber-chart":
            command_chamber_chart(args)
        elif args.command == "fcc-chart":
            command_fcc_chart(args)
    except Exception as exc:
        if args.command.startswith("fcc"):
            sources = source_status(FCC_DATA_SOURCES)
        elif args.command in ("chamber-summary", "chamber-chart") and getattr(args, "line_code", None) and getattr(args, "device", None):
            sources = source_status(chamber_data_sources(args.line_code, args.device))
        elif args.command.startswith("chamber"):
            sources = source_status(CHAMBER_DATA_SOURCES)
        else:
            sources = source_status()
        write_json(
            {
                "ok": False,
                "error": str(exc),
                "config": CONFIG,
                "diagnostics": {"version": LOADER_VERSION, "resolvedPaths": resolved_paths_for_command(args.command)},
                "sources": sources,
            }
        )
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
